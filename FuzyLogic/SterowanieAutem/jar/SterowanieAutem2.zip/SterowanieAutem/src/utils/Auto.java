package utils;

import java.awt.Color;


public class Auto extends Przeszkoda {
    public Auto(int x, int y) {
        super(x, y);
        this.setWidth(30);
        this.setHeight(30);
        this.setKolor(new Color(0,0,0));
    }  
}
